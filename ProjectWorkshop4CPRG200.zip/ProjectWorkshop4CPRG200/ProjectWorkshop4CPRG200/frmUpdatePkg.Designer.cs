﻿namespace ProjectWorkshop4CPRG200
{
    partial class frmUpdatePackage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label pkgAgencyCommissionLabel;
            System.Windows.Forms.Label pkgBasePriceLabel;
            System.Windows.Forms.Label pkgStartDateLabel;
            System.Windows.Forms.Label lblPkgName;
            System.Windows.Forms.Label lblPkgEndDate;
            System.Windows.Forms.Label lblPkgACnv;
            System.Windows.Forms.Label lblPkgBpnv;
            System.Windows.Forms.Label lblPkgEDnv;
            System.Windows.Forms.Label lblPkgNamenv;
            System.Windows.Forms.Label lblPkgSDnv;
            this.grpBxOldPkg = new System.Windows.Forms.GroupBox();
            this.txtPkgDescOv = new System.Windows.Forms.TextBox();
            this.lblPkgDescOv = new System.Windows.Forms.Label();
            this.txtpkgAgencyCommissionOv = new System.Windows.Forms.TextBox();
            this.packageBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.txtpkgBasePriceOv = new System.Windows.Forms.TextBox();
            this.pkgEndDateTimePickerOv = new System.Windows.Forms.DateTimePicker();
            this.txtPkgNameOv = new System.Windows.Forms.TextBox();
            this.pkgStartDateTimePickerOv = new System.Windows.Forms.DateTimePicker();
            this.grpBxNewValue = new System.Windows.Forms.GroupBox();
            this.txtPkgDescNv = new System.Windows.Forms.TextBox();
            this.lblPkgDescNv = new System.Windows.Forms.Label();
            this.txtPkgAgencyCommissionNv = new System.Windows.Forms.TextBox();
            this.txtPkgBasePriceNv = new System.Windows.Forms.TextBox();
            this.dateTimePickerEndDateNv = new System.Windows.Forms.DateTimePicker();
            this.txtPkgNameNv = new System.Windows.Forms.TextBox();
            this.dateTimePickerPkgStartDateNv = new System.Windows.Forms.DateTimePicker();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnAccept = new System.Windows.Forms.Button();
            this.chkStartDateNull = new System.Windows.Forms.CheckBox();
            this.chkEndDateNull = new System.Windows.Forms.CheckBox();
            pkgAgencyCommissionLabel = new System.Windows.Forms.Label();
            pkgBasePriceLabel = new System.Windows.Forms.Label();
            pkgStartDateLabel = new System.Windows.Forms.Label();
            lblPkgName = new System.Windows.Forms.Label();
            lblPkgEndDate = new System.Windows.Forms.Label();
            lblPkgACnv = new System.Windows.Forms.Label();
            lblPkgBpnv = new System.Windows.Forms.Label();
            lblPkgEDnv = new System.Windows.Forms.Label();
            lblPkgNamenv = new System.Windows.Forms.Label();
            lblPkgSDnv = new System.Windows.Forms.Label();
            this.grpBxOldPkg.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.packageBindingSource)).BeginInit();
            this.grpBxNewValue.SuspendLayout();
            this.SuspendLayout();
            // 
            // pkgAgencyCommissionLabel
            // 
            pkgAgencyCommissionLabel.AutoSize = true;
            pkgAgencyCommissionLabel.Location = new System.Drawing.Point(6, 207);
            pkgAgencyCommissionLabel.Name = "pkgAgencyCommissionLabel";
            pkgAgencyCommissionLabel.Size = new System.Drawing.Size(187, 20);
            pkgAgencyCommissionLabel.TabIndex = 2;
            pkgAgencyCommissionLabel.Text = "Pkg Agency Commission:";
            // 
            // pkgBasePriceLabel
            // 
            pkgBasePriceLabel.AutoSize = true;
            pkgBasePriceLabel.Location = new System.Drawing.Point(6, 175);
            pkgBasePriceLabel.Name = "pkgBasePriceLabel";
            pkgBasePriceLabel.Size = new System.Drawing.Size(120, 20);
            pkgBasePriceLabel.TabIndex = 4;
            pkgBasePriceLabel.Text = "Pkg Base Price:";
            // 
            // pkgStartDateLabel
            // 
            pkgStartDateLabel.AutoSize = true;
            pkgStartDateLabel.Location = new System.Drawing.Point(6, 77);
            pkgStartDateLabel.Name = "pkgStartDateLabel";
            pkgStartDateLabel.Size = new System.Drawing.Size(118, 20);
            pkgStartDateLabel.TabIndex = 10;
            pkgStartDateLabel.Text = "Pkg Start Date:";
            // 
            // lblPkgName
            // 
            lblPkgName.AutoSize = true;
            lblPkgName.Location = new System.Drawing.Point(6, 44);
            lblPkgName.Name = "lblPkgName";
            lblPkgName.Size = new System.Drawing.Size(86, 20);
            lblPkgName.TabIndex = 8;
            lblPkgName.Text = "Pkg Name:";
            // 
            // lblPkgEndDate
            // 
            lblPkgEndDate.AutoSize = true;
            lblPkgEndDate.Location = new System.Drawing.Point(6, 109);
            lblPkgEndDate.Name = "lblPkgEndDate";
            lblPkgEndDate.Size = new System.Drawing.Size(112, 20);
            lblPkgEndDate.TabIndex = 6;
            lblPkgEndDate.Text = "Pkg End Date:";
            // 
            // lblPkgACnv
            // 
            lblPkgACnv.AutoSize = true;
            lblPkgACnv.Location = new System.Drawing.Point(6, 210);
            lblPkgACnv.Name = "lblPkgACnv";
            lblPkgACnv.Size = new System.Drawing.Size(187, 20);
            lblPkgACnv.TabIndex = 2;
            lblPkgACnv.Text = "Pkg Agency Commission:";
            // 
            // lblPkgBpnv
            // 
            lblPkgBpnv.AutoSize = true;
            lblPkgBpnv.Location = new System.Drawing.Point(6, 178);
            lblPkgBpnv.Name = "lblPkgBpnv";
            lblPkgBpnv.Size = new System.Drawing.Size(120, 20);
            lblPkgBpnv.TabIndex = 4;
            lblPkgBpnv.Text = "Pkg Base Price:";
            // 
            // lblPkgEDnv
            // 
            lblPkgEDnv.AutoSize = true;
            lblPkgEDnv.Location = new System.Drawing.Point(6, 109);
            lblPkgEDnv.Name = "lblPkgEDnv";
            lblPkgEDnv.Size = new System.Drawing.Size(112, 20);
            lblPkgEDnv.TabIndex = 6;
            lblPkgEDnv.Text = "Pkg End Date:";
            // 
            // lblPkgNamenv
            // 
            lblPkgNamenv.AutoSize = true;
            lblPkgNamenv.Location = new System.Drawing.Point(6, 44);
            lblPkgNamenv.Name = "lblPkgNamenv";
            lblPkgNamenv.Size = new System.Drawing.Size(86, 20);
            lblPkgNamenv.TabIndex = 8;
            lblPkgNamenv.Text = "Pkg Name:";
            // 
            // lblPkgSDnv
            // 
            lblPkgSDnv.AutoSize = true;
            lblPkgSDnv.Location = new System.Drawing.Point(6, 77);
            lblPkgSDnv.Name = "lblPkgSDnv";
            lblPkgSDnv.Size = new System.Drawing.Size(118, 20);
            lblPkgSDnv.TabIndex = 10;
            lblPkgSDnv.Text = "Pkg Start Date:";
            // 
            // grpBxOldPkg
            // 
            this.grpBxOldPkg.Controls.Add(this.txtPkgDescOv);
            this.grpBxOldPkg.Controls.Add(this.lblPkgDescOv);
            this.grpBxOldPkg.Controls.Add(pkgAgencyCommissionLabel);
            this.grpBxOldPkg.Controls.Add(this.txtpkgAgencyCommissionOv);
            this.grpBxOldPkg.Controls.Add(pkgBasePriceLabel);
            this.grpBxOldPkg.Controls.Add(this.txtpkgBasePriceOv);
            this.grpBxOldPkg.Controls.Add(lblPkgEndDate);
            this.grpBxOldPkg.Controls.Add(this.pkgEndDateTimePickerOv);
            this.grpBxOldPkg.Controls.Add(lblPkgName);
            this.grpBxOldPkg.Controls.Add(this.txtPkgNameOv);
            this.grpBxOldPkg.Controls.Add(pkgStartDateLabel);
            this.grpBxOldPkg.Controls.Add(this.pkgStartDateTimePickerOv);
            this.grpBxOldPkg.Location = new System.Drawing.Point(12, 13);
            this.grpBxOldPkg.Name = "grpBxOldPkg";
            this.grpBxOldPkg.Size = new System.Drawing.Size(451, 254);
            this.grpBxOldPkg.TabIndex = 0;
            this.grpBxOldPkg.TabStop = false;
            this.grpBxOldPkg.Text = "Old Value";
            // 
            // txtPkgDescOv
            // 
            this.txtPkgDescOv.Location = new System.Drawing.Point(199, 137);
            this.txtPkgDescOv.Name = "txtPkgDescOv";
            this.txtPkgDescOv.ReadOnly = true;
            this.txtPkgDescOv.Size = new System.Drawing.Size(200, 26);
            this.txtPkgDescOv.TabIndex = 13;
            // 
            // lblPkgDescOv
            // 
            this.lblPkgDescOv.AutoSize = true;
            this.lblPkgDescOv.Location = new System.Drawing.Point(6, 140);
            this.lblPkgDescOv.Name = "lblPkgDescOv";
            this.lblPkgDescOv.Size = new System.Drawing.Size(124, 20);
            this.lblPkgDescOv.TabIndex = 12;
            this.lblPkgDescOv.Text = "Pkg Description:";
            // 
            // txtpkgAgencyCommissionOv
            // 
            this.txtpkgAgencyCommissionOv.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.packageBindingSource, "PkgAgencyCommission", true));
            this.txtpkgAgencyCommissionOv.Location = new System.Drawing.Point(199, 204);
            this.txtpkgAgencyCommissionOv.Name = "txtpkgAgencyCommissionOv";
            this.txtpkgAgencyCommissionOv.ReadOnly = true;
            this.txtpkgAgencyCommissionOv.Size = new System.Drawing.Size(200, 26);
            this.txtpkgAgencyCommissionOv.TabIndex = 3;
            // 
            // packageBindingSource
            // 
            this.packageBindingSource.DataSource = typeof(ProjectWorkshop4CPRG200.Package);
            // 
            // txtpkgBasePriceOv
            // 
            this.txtpkgBasePriceOv.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.packageBindingSource, "PkgBasePrice", true));
            this.txtpkgBasePriceOv.Location = new System.Drawing.Point(199, 172);
            this.txtpkgBasePriceOv.Name = "txtpkgBasePriceOv";
            this.txtpkgBasePriceOv.ReadOnly = true;
            this.txtpkgBasePriceOv.Size = new System.Drawing.Size(200, 26);
            this.txtpkgBasePriceOv.TabIndex = 5;
            // 
            // pkgEndDateTimePickerOv
            // 
            this.pkgEndDateTimePickerOv.Location = new System.Drawing.Point(199, 105);
            this.pkgEndDateTimePickerOv.Name = "pkgEndDateTimePickerOv";
            this.pkgEndDateTimePickerOv.Size = new System.Drawing.Size(200, 26);
            this.pkgEndDateTimePickerOv.TabIndex = 7;
            // 
            // txtPkgNameOv
            // 
            this.txtPkgNameOv.Location = new System.Drawing.Point(199, 41);
            this.txtPkgNameOv.Name = "txtPkgNameOv";
            this.txtPkgNameOv.ReadOnly = true;
            this.txtPkgNameOv.Size = new System.Drawing.Size(200, 26);
            this.txtPkgNameOv.TabIndex = 9;
            // 
            // pkgStartDateTimePickerOv
            // 
            this.pkgStartDateTimePickerOv.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.packageBindingSource, "PkgStartDate", true));
            this.pkgStartDateTimePickerOv.Location = new System.Drawing.Point(199, 73);
            this.pkgStartDateTimePickerOv.Name = "pkgStartDateTimePickerOv";
            this.pkgStartDateTimePickerOv.Size = new System.Drawing.Size(200, 26);
            this.pkgStartDateTimePickerOv.TabIndex = 11;
            // 
            // grpBxNewValue
            // 
            this.grpBxNewValue.Controls.Add(this.chkEndDateNull);
            this.grpBxNewValue.Controls.Add(this.chkStartDateNull);
            this.grpBxNewValue.Controls.Add(this.txtPkgDescNv);
            this.grpBxNewValue.Controls.Add(this.lblPkgDescNv);
            this.grpBxNewValue.Controls.Add(lblPkgACnv);
            this.grpBxNewValue.Controls.Add(this.txtPkgAgencyCommissionNv);
            this.grpBxNewValue.Controls.Add(lblPkgBpnv);
            this.grpBxNewValue.Controls.Add(this.txtPkgBasePriceNv);
            this.grpBxNewValue.Controls.Add(lblPkgEDnv);
            this.grpBxNewValue.Controls.Add(this.dateTimePickerEndDateNv);
            this.grpBxNewValue.Controls.Add(lblPkgNamenv);
            this.grpBxNewValue.Controls.Add(this.txtPkgNameNv);
            this.grpBxNewValue.Controls.Add(lblPkgSDnv);
            this.grpBxNewValue.Controls.Add(this.dateTimePickerPkgStartDateNv);
            this.grpBxNewValue.Location = new System.Drawing.Point(524, 13);
            this.grpBxNewValue.Name = "grpBxNewValue";
            this.grpBxNewValue.Size = new System.Drawing.Size(494, 256);
            this.grpBxNewValue.TabIndex = 12;
            this.grpBxNewValue.TabStop = false;
            this.grpBxNewValue.Text = "New Value";
            // 
            // txtPkgDescNv
            // 
            this.txtPkgDescNv.Location = new System.Drawing.Point(199, 143);
            this.txtPkgDescNv.Name = "txtPkgDescNv";
            this.txtPkgDescNv.Size = new System.Drawing.Size(200, 26);
            this.txtPkgDescNv.TabIndex = 15;
            // 
            // lblPkgDescNv
            // 
            this.lblPkgDescNv.AutoSize = true;
            this.lblPkgDescNv.Location = new System.Drawing.Point(6, 146);
            this.lblPkgDescNv.Name = "lblPkgDescNv";
            this.lblPkgDescNv.Size = new System.Drawing.Size(124, 20);
            this.lblPkgDescNv.TabIndex = 14;
            this.lblPkgDescNv.Text = "Pkg Description:";
            // 
            // txtPkgAgencyCommissionNv
            // 
            this.txtPkgAgencyCommissionNv.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.packageBindingSource, "PkgAgencyCommission", true));
            this.txtPkgAgencyCommissionNv.Location = new System.Drawing.Point(199, 207);
            this.txtPkgAgencyCommissionNv.Name = "txtPkgAgencyCommissionNv";
            this.txtPkgAgencyCommissionNv.Size = new System.Drawing.Size(200, 26);
            this.txtPkgAgencyCommissionNv.TabIndex = 3;
            // 
            // txtPkgBasePriceNv
            // 
            this.txtPkgBasePriceNv.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.packageBindingSource, "PkgBasePrice", true));
            this.txtPkgBasePriceNv.Location = new System.Drawing.Point(199, 175);
            this.txtPkgBasePriceNv.Name = "txtPkgBasePriceNv";
            this.txtPkgBasePriceNv.Size = new System.Drawing.Size(200, 26);
            this.txtPkgBasePriceNv.TabIndex = 5;
            // 
            // dateTimePickerEndDateNv
            // 
            this.dateTimePickerEndDateNv.Location = new System.Drawing.Point(199, 105);
            this.dateTimePickerEndDateNv.Name = "dateTimePickerEndDateNv";
            this.dateTimePickerEndDateNv.Size = new System.Drawing.Size(200, 26);
            this.dateTimePickerEndDateNv.TabIndex = 7;
            // 
            // txtPkgNameNv
            // 
            this.txtPkgNameNv.Location = new System.Drawing.Point(199, 41);
            this.txtPkgNameNv.Name = "txtPkgNameNv";
            this.txtPkgNameNv.Size = new System.Drawing.Size(200, 26);
            this.txtPkgNameNv.TabIndex = 9;
            // 
            // dateTimePickerPkgStartDateNv
            // 
            this.dateTimePickerPkgStartDateNv.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.packageBindingSource, "PkgStartDate", true));
            this.dateTimePickerPkgStartDateNv.Location = new System.Drawing.Point(199, 73);
            this.dateTimePickerPkgStartDateNv.Name = "dateTimePickerPkgStartDateNv";
            this.dateTimePickerPkgStartDateNv.Size = new System.Drawing.Size(200, 26);
            this.dateTimePickerPkgStartDateNv.TabIndex = 11;
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(871, 277);
            this.btnCancel.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(112, 35);
            this.btnCancel.TabIndex = 27;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnAccept
            // 
            this.btnAccept.Location = new System.Drawing.Point(732, 277);
            this.btnAccept.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnAccept.Name = "btnAccept";
            this.btnAccept.Size = new System.Drawing.Size(112, 35);
            this.btnAccept.TabIndex = 26;
            this.btnAccept.Text = "Accept";
            this.btnAccept.UseVisualStyleBackColor = true;
            this.btnAccept.Click += new System.EventHandler(this.btnAccept_Click);
            // 
            // chkStartDateNull
            // 
            this.chkStartDateNull.AutoSize = true;
            this.chkStartDateNull.Location = new System.Drawing.Point(415, 73);
            this.chkStartDateNull.Name = "chkStartDateNull";
            this.chkStartDateNull.Size = new System.Drawing.Size(61, 24);
            this.chkStartDateNull.TabIndex = 16;
            this.chkStartDateNull.Text = "Null";
            this.chkStartDateNull.UseVisualStyleBackColor = true;
            // 
            // chkEndDateNull
            // 
            this.chkEndDateNull.AutoSize = true;
            this.chkEndDateNull.Location = new System.Drawing.Point(415, 109);
            this.chkEndDateNull.Name = "chkEndDateNull";
            this.chkEndDateNull.Size = new System.Drawing.Size(61, 24);
            this.chkEndDateNull.TabIndex = 17;
            this.chkEndDateNull.Text = "Null";
            this.chkEndDateNull.UseVisualStyleBackColor = true;
            // 
            // frmUpdatePackage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1165, 326);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnAccept);
            this.Controls.Add(this.grpBxNewValue);
            this.Controls.Add(this.grpBxOldPkg);
            this.Name = "frmUpdatePackage";
            this.Text = "Update Package";
            this.Load += new System.EventHandler(this.frmUpdatePackage_Load);
            this.grpBxOldPkg.ResumeLayout(false);
            this.grpBxOldPkg.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.packageBindingSource)).EndInit();
            this.grpBxNewValue.ResumeLayout(false);
            this.grpBxNewValue.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpBxOldPkg;
        private System.Windows.Forms.TextBox txtpkgAgencyCommissionOv;
        private System.Windows.Forms.BindingSource packageBindingSource;
        private System.Windows.Forms.TextBox txtpkgBasePriceOv;
        private System.Windows.Forms.DateTimePicker pkgEndDateTimePickerOv;
        private System.Windows.Forms.TextBox txtPkgNameOv;
        private System.Windows.Forms.DateTimePicker pkgStartDateTimePickerOv;
        private System.Windows.Forms.GroupBox grpBxNewValue;
        private System.Windows.Forms.TextBox txtPkgAgencyCommissionNv;
        private System.Windows.Forms.TextBox txtPkgBasePriceNv;
        private System.Windows.Forms.DateTimePicker dateTimePickerEndDateNv;
        private System.Windows.Forms.TextBox txtPkgNameNv;
        private System.Windows.Forms.DateTimePicker dateTimePickerPkgStartDateNv;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnAccept;
        private System.Windows.Forms.TextBox txtPkgDescOv;
        private System.Windows.Forms.Label lblPkgDescOv;
        private System.Windows.Forms.TextBox txtPkgDescNv;
        private System.Windows.Forms.Label lblPkgDescNv;
        private System.Windows.Forms.CheckBox chkEndDateNull;
        private System.Windows.Forms.CheckBox chkStartDateNull;
    }
}