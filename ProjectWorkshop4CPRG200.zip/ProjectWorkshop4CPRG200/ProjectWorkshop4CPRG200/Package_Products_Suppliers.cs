﻿//Packages_Products_Suppliers class : all the property of Packages_Products_Suppliers
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectWorkshop4CPRG200
{
    public class Packages_Products_Suppliers
    {
        //Class property
        public int PackageID { get; set; }
        public int ProductSupplierID { get; set; }

    }
}
